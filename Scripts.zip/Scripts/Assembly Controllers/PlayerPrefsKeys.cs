﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
internal class PlayerPrefsKeys
{
    public const string AudioVolume = "AudioVolume";
    public const string Lives = "Lives";
    public const string PlayerHealth = "PlayerHealth";
    public const string SFXVolume = "SFX Volume";
    public const string PlayerColorVariant = "PlayerColorVariant";
}
