﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Audio;
using UnityEngine.UI;
using System.IO;
using UnityEditor;

public class GameData : MonoBehaviour
{
    //INIParser ini = new INIParser();
    float volume;


    private void Start()
    {
       // ini.Open(Application.dataPath + "GameConfig.ini");
       // volume = ini.ReadValue("Settings","Volume", 1);
    }

    // Start is called before the first frame update
    void getPath()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
