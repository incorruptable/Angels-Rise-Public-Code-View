using UnityEngine;
using System.Collections;

public class EnemyFiring : MonoBehaviour
{
    private EnemyStats stats;
    private EnemyAnimationManager animationManager;
    private float cooldownTimer;
    private bool isCharging;
    private bool canFire = false;

    public void Initialize(EnemyStats stats, EnemyAnimationManager animationManager)
    {
        this.stats = stats;
        this.animationManager = animationManager;

        cooldownTimer = stats.fireCooldown;
    }

    public void HandleFiring()
    {
        cooldownTimer -= Time.deltaTime;
        if (cooldownTimer < 0f && !isCharging && canFire) StartCoroutine(FireSequence());
    }

    private IEnumerator FireSequence()
    {
        canFire = false;
        isCharging = true;

        animationManager?.StartChargingAnimation();

        yield return new WaitForSeconds(stats.fireCooldown);

        animationManager?.StopChargingAnimation();

        if(stats.defaultWeaponPrefab != null && stats.firePoint != null)
            Instantiate(stats.defaultWeaponPrefab, stats.firePoint.position, stats.firePoint.rotation);

        cooldownTimer = stats.fireCooldown;
        isCharging = false;
        canFire = true;
    }
}
